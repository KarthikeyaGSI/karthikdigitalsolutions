import React, { useState, useEffect, Suspense, lazy } from 'react';
import { Mail, Menu, X, ChevronDown, Linkedin, Youtube, PenTool, BookOpen, Zap, Sparkles, Phone, Calendar, Download, TrendingUp, Users, Award, CheckCircle, ArrowRight, Star, DollarSign, Target, Clock } from 'lucide-react';
import { motion } from 'framer-motion';
import { Toaster, toast } from 'sonner';
import { InlineWidget } from 'react-calendly';
import LoadingState from './components/LoadingState';
import ErrorBoundary from './components/ErrorBoundary';
import ChatWidget from './components/ChatWidget';

const ROICalculator = lazy(() => import('./components/ROICalculator'));
const TrustSignals = lazy(() => import('./components/TrustSignals'));
const CaseStudies = lazy(() => import('./components/CaseStudies'));
const ServicePackages = lazy(() => import('./components/ServicePackages'));

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isCalendlyModalOpen, setIsCalendlyModalOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [selectedService, setSelectedService] = useState('');

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleServiceClick = (service: string) => {
    setSelectedService(service);
    scrollToSection('contact');
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    const formData = new FormData(e.currentTarget);
    const name = formData.get('name') || 'Not provided';
    const email = formData.get('email') || 'Not provided';
    const company = formData.get('company') || 'Not provided';
    const phone = formData.get('phone') || 'Not provided';
    const revenue = formData.get('revenue') || 'Not provided';
    const challenge = formData.get('challenge') || 'Not provided';
    const budget = formData.get('budget') || 'Not provided';
    const timeline = formData.get('timeline') || 'Not provided';
    
    const subject = `High-Value Lead: ${name} from ${company}`;
    const body = `QUALIFIED LEAD ALERT!

Contact Details:
Name: ${name}
Email: ${email}
Company: ${company}
Phone: ${phone}

Business Information:
Monthly Revenue: ${revenue}
Primary Challenge: ${challenge}
Investment Budget: ${budget}
Timeline: ${timeline}

This lead came through the strategy session form and appears to be a qualified prospect.

Best regards,
${name}`;
    
    window.location.href = `mailto:karthikeya.gsi@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    toast.success('Thank you! We\'ll contact you within 24 hours.');
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  const Logo = () => (
    <a href="/" className="text-xl md:text-2xl font-bold neon-text-cyan animate-pulse">
      <span className="flex items-center gap-2">
        <Zap className="w-6 h-6 text-cyan-400" />
        Karthik Digital Solutions
      </span>
    </a>
  );

  return (
    <div className="font-sans text-white bg-black min-h-screen relative overflow-x-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-black via-purple-900/20 to-black"></div>
        <div className="absolute top-0 left-0 w-full h-full">
          <div className="neon-grid"></div>
        </div>
        {/* Floating neon particles */}
        <div className="neon-particles">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className={`neon-particle neon-particle-${i % 5 + 1}`}
              style={{
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 10}s`,
                animationDuration: `${10 + Math.random() * 20}s`
              }}
            ></div>
          ))}
        </div>
      </div>

      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${scrolled ? 'neon-bg-dark backdrop-blur-xl' : 'bg-black/80 backdrop-blur-md'} border-b border-cyan-400/30 neon-border-glow`}>
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <Logo />
            
            <div className="hidden md:flex space-x-8">
              {['home', 'results', 'services', 'process', 'contact'].map((item) => (
                <button 
                  key={item}
                  onClick={() => scrollToSection(item)}
                  className="neon-text-white hover:neon-text-cyan font-medium transition-all duration-300 relative group neon-hover-glow"
                >
                  {item.charAt(0).toUpperCase() + item.slice(1)}
                  <span className="absolute bottom-[-5px] left-0 w-0 h-0.5 bg-gradient-to-r from-cyan-400 to-pink-500 transition-all duration-300 group-hover:w-full neon-line-glow"></span>
                </button>
              ))}
            </div>
            
            <button 
              className="md:hidden text-cyan-400 neon-text-glow"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-label={isMenuOpen ? 'Close menu' : 'Open menu'}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden neon-bg-dark backdrop-blur-xl border-t border-cyan-400/30 py-4"
          >
            <div className="container mx-auto px-4 flex flex-col space-y-4">
              {['home', 'results', 'services', 'process', 'contact'].map((item) => (
                <button 
                  key={item}
                  onClick={() => scrollToSection(item)}
                  className="neon-text-white hover:neon-text-cyan py-2 font-medium transition-all duration-300 text-left neon-hover-glow"
                >
                  {item.charAt(0).toUpperCase() + item.slice(1)}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </nav>

      {/* Hero Section - Conversion Focused */}
      <section id="home" className="min-h-screen flex items-center relative overflow-hidden px-4 md:px-0 z-10">
        <div className="container mx-auto z-10 py-20">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="max-w-3xl"
            >
              <motion.h1 
                className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6 leading-tight neon-text-gradient animate-pulse"
                initial={{ scale: 0.9 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
              >
                Turn Your Marketing Spend Into <span className="neon-text-cyan">Measurable Revenue</span> Growth
              </motion.h1>
              <div className="text-lg sm:text-xl md:text-2xl neon-text-purple mb-8 font-light">
                <Sparkles className="inline w-6 h-6 mr-2" />
                Proven strategies and custom development that have generated <span className="neon-text-pink font-bold">$2M+</span> in client revenue
              </div>
              
              {/* Key Benefits */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-10">
                <div className="flex items-center gap-3 neon-card neon-card-cyan p-4">
                  <CheckCircle className="w-6 h-6 neon-text-cyan flex-shrink-0" />
                  <span className="text-white font-semibold">150% Average ROI Increase</span>
                </div>
                <div className="flex items-center gap-3 neon-card neon-card-pink p-4">
                  <CheckCircle className="w-6 h-6 neon-text-pink flex-shrink-0" />
                  <span className="text-white font-semibold">90-Day Results Guarantee</span>
                </div>
                <div className="flex items-center gap-3 neon-card neon-card-purple p-4">
                  <CheckCircle className="w-6 h-6 neon-text-purple flex-shrink-0" />
                  <span className="text-white font-semibold">Full-Service Solution</span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <motion.button 
                  whileHover={{ y: -3, scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setIsCalendlyModalOpen(true)}
                  className="neon-btn-primary relative overflow-hidden group flex items-center justify-center gap-2"
                >
                  <Calendar size={20} />
                  <span className="relative z-10">Get Your Free Growth Strategy Session</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-pink-500 opacity-0 group-hover:opacity-20 transition-opacity duration-300"></div>
                </motion.button>
                <motion.button 
                  whileHover={{ y: -3, scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => scrollToSection('results')}
                  className="neon-btn-secondary flex items-center justify-center gap-2"
                >
                  <TrendingUp size={18} />
                  View Our Case Studies
                </motion.button>
              </div>

              {/* Social Proof Indicators */}
              <div className="mt-8 pt-8 border-t border-cyan-400/30">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold neon-text-cyan">$2.5M+</div>
                    <div className="text-sm text-gray-400">Revenue Generated</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold neon-text-pink">150+</div>
                    <div className="text-sm text-gray-400">Projects Delivered</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold neon-text-purple">98%</div>
                    <div className="text-sm text-gray-400">Client Satisfaction</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold neon-text-green">30+</div>
                    <div className="text-sm text-gray-400">Industries Served</div>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <div className="hidden md:block">
              <ErrorBoundary>
                <Suspense fallback={<LoadingState />}>
                  <ROICalculator />
                </Suspense>
              </ErrorBoundary>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Signals Section */}
      <ErrorBoundary>
        <Suspense fallback={<LoadingState />}>
          <TrustSignals />
        </Suspense>
      </ErrorBoundary>

      {/* Case Studies Section */}
      <section id="results" className="py-16 md:py-24 relative z-10 px-4 md:px-0">
        <ErrorBoundary>
          <Suspense fallback={<LoadingState />}>
            <CaseStudies />
          </Suspense>
        </ErrorBoundary>
      </section>

      {/* Services Section - Revenue Focused */}
      <section id="services" className="py-16 md:py-24 relative z-10 px-4 md:px-0">
        <div className="container mx-auto">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-3xl md:text-4xl font-bold mb-4 text-center neon-text-gradient"
          >
            Services That Drive <span className="neon-text-cyan">Measurable Results</span>
          </motion.h2>
          <p className="text-base md:text-lg text-gray-300 text-center mb-12 md:mb-16 max-w-3xl mx-auto">
            We don't just build websites and run ads. We create complete digital ecosystems that turn your marketing investment into predictable revenue growth.
          </p>
          
          <ErrorBoundary>
            <Suspense fallback={<LoadingState />}>
              <ServicePackages onServiceClick={handleServiceClick} />
            </Suspense>
          </ErrorBoundary>
        </div>
      </section>

      {/* Process Section */}
      <section id="process" className="py-16 md:py-24 relative z-10 px-4 md:px-0">
        <div className="container mx-auto">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-3xl md:text-4xl font-bold mb-4 text-center neon-text-gradient"
          >
            Our Proven <span className="neon-text-cyan">4-Step Process</span>
          </motion.h2>
          <p className="text-base md:text-lg text-gray-300 text-center mb-12 md:mb-16 max-w-2xl mx-auto">
            From strategy to execution, we follow a systematic approach that ensures your success.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                step: "01",
                title: "Strategy & Analysis",
                description: "Deep dive into your business, market analysis, and growth opportunity identification.",
                icon: <Target className="w-8 h-8" />,
                color: "cyan",
                timeline: "Week 1"
              },
              {
                step: "02", 
                title: "Custom Development",
                description: "Build high-converting websites and marketing systems tailored to your business goals.",
                icon: <Zap className="w-8 h-8" />,
                color: "pink",
                timeline: "Weeks 2-4"
              },
              {
                step: "03",
                title: "Campaign Launch",
                description: "Deploy optimized marketing campaigns across multiple channels with advanced tracking.",
                icon: <TrendingUp className="w-8 h-8" />,
                color: "purple",
                timeline: "Week 5"
              },
              {
                step: "04",
                title: "Optimize & Scale",
                description: "Continuous optimization based on data insights to maximize ROI and scale results.",
                icon: <DollarSign className="w-8 h-8" />,
                color: "green",
                timeline: "Ongoing"
              }
            ].map((process, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className={`neon-card neon-card-${process.color} text-center relative`}
              >
                <div className={`w-16 h-16 mx-auto mb-6 neon-icon-bg-${process.color} rounded-2xl flex items-center justify-center neon-text-${process.color} neon-glow-${process.color}`}>
                  {process.icon}
                </div>
                <div className={`text-4xl font-bold neon-text-${process.color} mb-2`}>{process.step}</div>
                <h3 className="text-xl font-bold text-white mb-4 neon-text-glow">{process.title}</h3>
                <p className="text-gray-300 mb-4">{process.description}</p>
                <div className={`inline-block px-3 py-1 rounded-full text-sm neon-text-${process.color} border border-current`}>
                  {process.timeline}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section - Lead Qualification */}
      <section id="contact" className="py-16 md:py-24 relative z-10 px-4 md:px-0">
        <div className="container mx-auto">
          <div className="text-center max-w-4xl mx-auto">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="text-3xl md:text-4xl font-bold mb-4 neon-text-gradient"
            >
              Ready to <span className="neon-text-pink">3x Your Revenue</span> in 90 Days?
            </motion.h2>
            <p className="text-base md:text-lg text-gray-300 mb-12">
              Book your free strategy session and discover exactly how we'll grow your business with our proven system.
            </p>

            <div className="grid md:grid-cols-2 gap-12 mb-12">
              {/* Strategy Session Booking */}
              <div className="neon-card neon-card-cyan">
                <h3 className="text-2xl font-bold neon-text-cyan mb-6 flex items-center gap-2">
                  <Calendar className="w-6 h-6" />
                  Free Growth Strategy Session
                </h3>
                <div className="space-y-4 mb-6">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 neon-text-cyan" />
                    <span>45-minute consultation with growth expert</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 neon-text-cyan" />
                    <span>Custom growth plan for your business</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 neon-text-cyan" />
                    <span>ROI projections and timeline</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 neon-text-cyan" />
                    <span>No-obligation actionable recommendations</span>
                  </div>
                </div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setIsCalendlyModalOpen(true)}
                  className="neon-btn-primary w-full"
                >
                  <Calendar size={20} />
                  Book Your Free Session Now
                </motion.button>
              </div>

              {/* Lead Qualification Form */}
              <div className="neon-card neon-card-purple">
                <h3 className="text-2xl font-bold neon-text-purple mb-6 flex items-center gap-2">
                  <Mail className="w-6 h-6" />
                  Get Custom Growth Proposal
                </h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input 
                      type="text" 
                      name="name" 
                      placeholder="Full Name" 
                      required
                      className="neon-input"
                    />
                    <input 
                      type="email" 
                      name="email" 
                      placeholder="Email Address" 
                      required
                      className="neon-input"
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input 
                      type="text" 
                      name="company" 
                      placeholder="Company Name"
                      required
                      className="neon-input"
                    />
                    <input 
                      type="tel" 
                      name="phone" 
                      placeholder="Phone Number"
                      required
                      className="neon-input"
                    />
                  </div>
                  <select 
                    name="revenue" 
                    required
                    className="neon-input w-full"
                  >
                    <option value="">Current Monthly Revenue</option>
                    <option value="$10K-$50K">$10K - $50K</option>
                    <option value="$50K-$100K">$50K - $100K</option>
                    <option value="$100K-$500K">$100K - $500K</option>
                    <option value="$500K+">$500K+</option>
                  </select>
                  <select 
                    name="budget" 
                    required
                    className="neon-input w-full"
                  >
                    <option value="">Investment Budget Range</option>
                    <option value="$3K-$5K">$3,000 - $5,000</option>
                    <option value="$5K-$10K">$5,000 - $10,000</option>
                    <option value="$10K-$15K">$10,000 - $15,000</option>
                    <option value="$15K+">$15,000+</option>
                  </select>
                  <textarea 
                    name="challenge" 
                    placeholder="What's your biggest business challenge right now?" 
                    required
                    rows={3}
                    className="neon-input resize-y w-full"
                  ></textarea>
                  <select 
                    name="timeline" 
                    required
                    className="neon-input w-full"
                  >
                    <option value="">Timeline for Implementation</option>
                    <option value="ASAP">As soon as possible</option>
                    <option value="1-3 months">Within 1-3 months</option>
                    <option value="3-6 months">Within 3-6 months</option>
                    <option value="6+ months">6+ months</option>
                  </select>
                  <motion.button 
                    type="submit"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="neon-btn-primary w-full"
                  >
                    <ArrowRight size={20} />
                    Get My Custom Growth Plan
                  </motion.button>
                </form>
              </div>
            </div>

            {/* Direct Contact */}
            <div className="neon-card neon-card-green p-6">
              <h3 className="text-xl font-semibold neon-text-green mb-4">Prefer to Talk Directly?</h3>
              <div className="flex flex-col sm:flex-row justify-center items-center gap-6">
                <a 
                  href="mailto:karthikeya.gsi@gmail.com" 
                  className="flex items-center gap-2 neon-text-white hover:neon-text-cyan transition-colors duration-300 neon-hover-glow"
                >
                  <Mail size={20} />
                  karthikeya.gsi@gmail.com
                </a>
                <a 
                  href="tel:+1234567890" 
                  className="flex items-center gap-2 neon-text-white hover:neon-text-cyan transition-colors duration-300 neon-hover-glow"
                >
                  <Phone size={20} />
                  Schedule a Call
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="neon-bg-dark border-t border-cyan-400/30 pt-12 pb-4 relative z-10">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
            <div className="col-span-2 md:col-span-1">
              <Logo />
              <p className="text-gray-400 mt-4 text-sm">
                Turning marketing investments into measurable business growth since 2020.
              </p>
            </div>

            <div className="col-span-1">
              <h3 className="text-white font-semibold mb-4 neon-text-glow">Quick Links</h3>
              <div className="flex flex-col gap-2">
                {['Case Studies', 'Services', 'Process', 'Contact'].map((item, index) => (
                  <button 
                    key={index}
                    onClick={() => scrollToSection(item.toLowerCase().replace(' ', ''))}
                    className="text-gray-400 hover:neon-text-cyan transition-colors duration-300 text-left text-sm neon-hover-glow"
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>

            <div className="col-span-1">
              <h3 className="text-white font-semibold mb-4 neon-text-glow">Resources</h3>
              <div className="flex flex-col gap-2">
                <a 
                  href="https://medium.com/@KarthikeyaGSI"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:neon-text-cyan transition-colors duration-300 text-sm neon-hover-glow"
                >
                  Growth Articles
                </a>
                <a 
                  href="https://www.linkedin.com/newsletters/global-sustainable-initiative-7325848775837577216"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:neon-text-cyan transition-colors duration-300 text-sm neon-hover-glow"
                >
                  Newsletter
                </a>
              </div>
            </div>

            <div className="col-span-1">
              <h3 className="text-white font-semibold mb-4 neon-text-glow">Connect</h3>
              <div className="flex flex-col gap-2">
                <a 
                  href="https://www.linkedin.com/in/karthikeyagsi/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:neon-text-cyan transition-colors duration-300 flex items-center gap-2 text-sm neon-hover-glow"
                >
                  <Linkedin size={16} />
                  LinkedIn
                </a>
                <a 
                  href="https://www.youtube.com/@karthikeyagsi"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:neon-text-cyan transition-colors duration-300 flex items-center gap-2 text-sm neon-hover-glow"
                >
                  <Youtube size={16} />
                  YouTube
                </a>
              </div>
            </div>
          </div>

          <div className="text-sm text-gray-500 text-center border-t border-cyan-400/20 pt-4">
            © 2025 Karthik Digital Solutions. All rights reserved. <span className="neon-text-cyan">Turning Marketing Into Revenue</span>
          </div>
        </div>
      </footer>

      {/* Calendly Modal */}
      {isCalendlyModalOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="neon-modal max-w-4xl w-full max-h-[90vh] overflow-hidden">
            <div className="neon-modal-header p-6 flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white neon-text-glow">Book Your Free Strategy Session</h2>
              <button 
                onClick={() => setIsCalendlyModalOpen(false)}
                className="text-white/80 hover:text-white transition-opacity neon-hover-glow"
              >
                <X size={24} />
              </button>
            </div>
            <div className="h-[600px]">
              <InlineWidget 
                url="https://calendly.com/tkgoud-26"
                styles={{
                  height: '100%',
                  width: '100%',
                }}
              />
            </div>
          </div>
        </div>
      )}

      <Toaster position="top-right" />
      <ChatWidget />
    </div>
  );
}

export default App;