import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Download, TrendingUp, DollarSign, Zap, Calculator, ArrowRight } from 'lucide-react';

export default function ROICalculator() {
  const [monthlyRevenue, setMonthlyRevenue] = useState<number>(50000);
  const [conversionRate, setConversionRate] = useState<number>(2);
  const [monthlyVisitors, setMonthlyVisitors] = useState<number>(5000);
  const [averageOrderValue, setAverageOrderValue] = useState<number>(150);
  
  const calculateProjections = () => {
    const currentMonthlyOrders = (monthlyVisitors * conversionRate) / 100;
    const currentRevenue = currentMonthlyOrders * averageOrderValue;
    
    // Conservative improvement estimates based on our case studies
    const improvedConversionRate = conversionRate * 2.5; // 150% improvement
    const improvedAOV = averageOrderValue * 1.3; // 30% improvement
    const improvedTraffic = monthlyVisitors * 1.5; // 50% improvement
    
    const projectedMonthlyOrders = (improvedTraffic * improvedConversionRate) / 100;
    const projectedRevenue = projectedMonthlyOrders * improvedAOV;
    
    const additionalRevenue = projectedRevenue - currentRevenue;
    const annualAdditionalRevenue = additionalRevenue * 12;
    
    return {
      currentRevenue: currentRevenue.toFixed(0),
      projectedRevenue: projectedRevenue.toFixed(0),
      additionalRevenue: additionalRevenue.toFixed(0),
      annualAdditionalRevenue: annualAdditionalRevenue.toFixed(0),
      roiPercentage: ((additionalRevenue / 10000) * 100).toFixed(0), // Assuming $10k investment
      paybackPeriod: Math.ceil(10000 / additionalRevenue) // Months to payback
    };
  };

  const handleEmailReport = () => {
    const projections = calculateProjections();
    const subject = "Your Business Growth ROI Projection";
    const body = `
Hello!

Here's your personalized Business Growth ROI Report:

Current Metrics:
- Monthly Revenue: $${projections.currentRevenue}
- Conversion Rate: ${conversionRate}%
- Monthly Visitors: ${monthlyVisitors.toLocaleString()}
- Average Order Value: $${averageOrderValue}

Projected Results with Our Growth Strategy:
- Projected Monthly Revenue: $${projections.projectedRevenue}
- Additional Monthly Revenue: $${projections.additionalRevenue}
- Annual Additional Revenue: $${projections.annualAdditionalRevenue}
- ROI: ${projections.roiPercentage}%
- Payback Period: ${projections.paybackPeriod} months

These projections are based on our average client results and proven strategies.

Ready to discuss how we can achieve these results for your business?
Book your free strategy session: https://calendly.com/tkgoud-26

Best regards,
Karthik Digital Solutions Team
    `;
    
    window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  const projections = calculateProjections();

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="neon-card neon-card-cyan"
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-semibold neon-text-cyan flex items-center gap-2">
          <Calculator className="w-5 h-5" />
          Growth ROI Calculator
        </h3>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleEmailReport}
          className="text-sm neon-text-cyan hover:neon-text-pink flex items-center gap-2 neon-hover-glow transition-colors duration-300"
        >
          <Download size={16} />
          Email Report
        </motion.button>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Monthly Website Visitors
          </label>
          <input
            type="number"
            value={monthlyVisitors}
            onChange={(e) => setMonthlyVisitors(Number(e.target.value))}
            className="neon-input w-full"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Current Conversion Rate (%)
          </label>
          <input
            type="number"
            step="0.1"
            value={conversionRate}
            onChange={(e) => setConversionRate(Number(e.target.value))}
            className="neon-input w-full"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Average Order Value ($)
          </label>
          <input
            type="number"
            value={averageOrderValue}
            onChange={(e) => setAverageOrderValue(Number(e.target.value))}
            className="neon-input w-full"
          />
        </div>

        <div className="grid grid-cols-1 gap-4 pt-6 border-t border-cyan-400/30">
          <div className="neon-card neon-card-cyan p-4">
            <div className="flex items-center gap-2 neon-text-cyan mb-2">
              <DollarSign size={16} />
              <span className="text-sm">Current Monthly Revenue</span>
            </div>
            <div className="text-2xl font-bold text-white neon-text-glow">
              ${Number(projections.currentRevenue).toLocaleString()}
            </div>
          </div>
          
          <div className="neon-card neon-card-pink p-4">
            <div className="flex items-center gap-2 neon-text-pink mb-2">
              <TrendingUp size={16} />
              <span className="text-sm">Projected Monthly Revenue</span>
            </div>
            <div className="text-2xl font-bold text-white neon-text-glow">
              ${Number(projections.projectedRevenue).toLocaleString()}
            </div>
          </div>

          <div className="neon-card neon-card-purple p-4">
            <div className="flex items-center gap-2 neon-text-purple mb-2">
              <Zap size={16} />
              <span className="text-sm">Additional Monthly Revenue</span>
            </div>
            <div className="text-2xl font-bold text-white neon-text-glow">
              ${Number(projections.additionalRevenue).toLocaleString()}
            </div>
            <div className="text-xs text-gray-400 mt-1">
              ${Number(projections.annualAdditionalRevenue).toLocaleString()} annually
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="neon-card neon-card-green p-4 text-center">
              <div className="text-sm neon-text-green mb-1">ROI</div>
              <div className="text-xl font-bold text-white neon-text-glow">
                {projections.roiPercentage}%
              </div>
            </div>
            <div className="neon-card neon-card-yellow p-4 text-center">
              <div className="text-sm neon-text-yellow mb-1">Payback</div>
              <div className="text-xl font-bold text-white neon-text-glow">
                {projections.paybackPeriod}mo
              </div>
            </div>
          </div>
        </div>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
          className="neon-btn-primary w-full mt-6"
        >
          <ArrowRight size={18} />
          Get My Custom Growth Plan
        </motion.button>
      </div>

      <div className="mt-4 p-3 bg-black/40 rounded-lg">
        <p className="text-xs text-gray-400 text-center">
          * Projections based on average client results. Individual results may vary.
        </p>
      </div>
    </motion.div>
  );
}