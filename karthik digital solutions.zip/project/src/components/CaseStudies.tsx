import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Users, DollarSign, Clock, ArrowRight, Star, CheckCircle } from 'lucide-react';

const caseStudies = [
  {
    client: "TechStart Solutions",
    industry: "SaaS",
    challenge: "2% conversion rate, high customer acquisition cost",
    solution: "Complete website redesign + marketing automation + A/B testing",
    results: {
      conversionIncrease: "180%",
      revenueGrowth: "250%",
      timeline: "4 months",
      roi: "400%"
    },
    testimonial: {
      quote: "Karthik increased our online sales by 180% in just 4 months. The ROI was immediate and continues to grow. Best investment we've made in our business.",
      author: "Sarah Johnson",
      role: "CEO",
      image: "/api/placeholder/60/60"
    },
    metrics: [
      { label: "Conversion Rate", before: "2%", after: "5.6%" },
      { label: "Monthly Revenue", before: "$45K", after: "$157K" },
      { label: "Customer LTV", before: "$2,400", after: "$4,200" }
    ],
    color: "cyan"
  },
  {
    client: "Green Energy Corp",
    industry: "Renewable Energy",
    challenge: "Low online visibility, poor lead quality",
    solution: "SEO optimization + LinkedIn campaigns + lead scoring system",
    results: {
      conversionIncrease: "320%",
      revenueGrowth: "180%",
      timeline: "6 months",
      roi: "350%"
    },
    testimonial: {
      quote: "Their strategic approach helped us reduce customer acquisition costs by 60% while tripling our qualified leads. Exceptional results.",
      author: "Michael Rodriguez",
      role: "Marketing Director",
      image: "/api/placeholder/60/60"
    },
    metrics: [
      { label: "Qualified Leads", before: "12/month", after: "85/month" },
      { label: "Cost per Lead", before: "$450", after: "$180" },
      { label: "Close Rate", before: "15%", after: "32%" }
    ],
    color: "pink"
  },
  {
    client: "Local E-commerce Retailer",
    industry: "E-commerce",
    challenge: "High cart abandonment, low repeat purchases",
    solution: "UX optimization + email automation + retargeting campaigns",
    results: {
      conversionIncrease: "160%",
      revenueGrowth: "220%",
      timeline: "3 months",
      roi: "380%"
    },
    testimonial: {
      quote: "Cart abandonment dropped from 70% to 35%, and our repeat purchase rate doubled. The email automation alone pays for itself.",
      author: "Lisa Chen",
      role: "Owner",
      image: "/api/placeholder/60/60"
    },
    metrics: [
      { label: "Cart Abandonment", before: "70%", after: "35%" },
      { label: "Repeat Purchases", before: "18%", after: "42%" },
      { label: "Average Order Value", before: "$85", after: "$127" }
    ],
    color: "purple"
  },
  {
    client: "Professional Services Firm",
    industry: "Consulting",
    challenge: "Inconsistent lead flow, long sales cycles",
    solution: "Content marketing + LinkedIn outreach + CRM automation",
    results: {
      conversionIncrease: "240%",
      revenueGrowth: "190%",
      timeline: "5 months",
      roi: "420%"
    },
    testimonial: {
      quote: "We went from feast or famine to predictable monthly revenue. The lead nurturing system is incredible - 40% of our clients now come from referrals.",
      author: "David Park",
      role: "Managing Partner",
      image: "/api/placeholder/60/60"
    },
    metrics: [
      { label: "Monthly Leads", before: "8", after: "35" },
      { label: "Sales Cycle", before: "6 months", after: "3.5 months" },
      { label: "Referral Rate", before: "10%", after: "40%" }
    ],
    color: "green"
  }
];

export default function CaseStudies() {
  return (
    <div className="container mx-auto">
      <motion.h2 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        className="text-3xl md:text-4xl font-bold mb-4 text-center neon-text-gradient"
      >
        Real Results from <span className="neon-text-cyan">Real Businesses</span>
      </motion.h2>
      <p className="text-base md:text-lg text-gray-300 text-center mb-12 md:mb-16 max-w-3xl mx-auto">
        See how we've helped businesses like yours achieve measurable growth and ROI. These aren't just numbers - they're transformed businesses.
      </p>

      <div className="space-y-16">
        {caseStudies.map((study, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            className={`neon-card neon-card-${study.color} relative overflow-hidden`}
          >
            <div className="grid md:grid-cols-2 gap-8">
              {/* Left Column - Challenge & Solution */}
              <div>
                <div className="flex items-center gap-4 mb-6">
                  <div className={`w-12 h-12 neon-icon-bg-${study.color} rounded-xl flex items-center justify-center neon-glow-${study.color}`}>
                    <TrendingUp className={`w-6 h-6 neon-text-${study.color}`} />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white neon-text-glow">{study.client}</h3>
                    <p className="text-gray-400">{study.industry}</p>
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <h4 className={`text-lg font-semibold neon-text-${study.color} mb-2`}>The Challenge</h4>
                    <p className="text-gray-300">{study.challenge}</p>
                  </div>

                  <div>
                    <h4 className={`text-lg font-semibold neon-text-${study.color} mb-2`}>Our Solution</h4>
                    <p className="text-gray-300">{study.solution}</p>
                  </div>

                  {/* Key Metrics */}
                  <div>
                    <h4 className={`text-lg font-semibold neon-text-${study.color} mb-4`}>Key Improvements</h4>
                    <div className="space-y-3">
                      {study.metrics.map((metric, idx) => (
                        <div key={idx} className="flex items-center justify-between p-3 bg-black/40 rounded-lg">
                          <span className="text-gray-300">{metric.label}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-red-400 line-through">{metric.before}</span>
                            <ArrowRight className="w-4 h-4 text-gray-400" />
                            <span className={`font-bold neon-text-${study.color}`}>{metric.after}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column - Results & Testimonial */}
              <div>
                {/* Results Grid */}
                <div className="grid grid-cols-2 gap-4 mb-8">
                  <div className={`neon-card neon-card-${study.color} p-6 text-center`}>
                    <DollarSign className={`w-8 h-8 neon-text-${study.color} mx-auto mb-2`} />
                    <div className="text-3xl font-bold text-white neon-text-glow">+{study.results.conversionIncrease}</div>
                    <div className="text-sm text-gray-400">Conversion Increase</div>
                  </div>
                  <div className={`neon-card neon-card-${study.color} p-6 text-center`}>
                    <TrendingUp className={`w-8 h-8 neon-text-${study.color} mx-auto mb-2`} />
                    <div className="text-3xl font-bold text-white neon-text-glow">+{study.results.revenueGrowth}</div>
                    <div className="text-sm text-gray-400">Revenue Growth</div>
                  </div>
                  <div className={`neon-card neon-card-${study.color} p-6 text-center`}>
                    <Clock className={`w-8 h-8 neon-text-${study.color} mx-auto mb-2`} />
                    <div className="text-3xl font-bold text-white neon-text-glow">{study.results.timeline}</div>
                    <div className="text-sm text-gray-400">Timeline</div>
                  </div>
                  <div className={`neon-card neon-card-${study.color} p-6 text-center`}>
                    <CheckCircle className={`w-8 h-8 neon-text-${study.color} mx-auto mb-2`} />
                    <div className="text-3xl font-bold text-white neon-text-glow">{study.results.roi}</div>
                    <div className="text-sm text-gray-400">ROI</div>
                  </div>
                </div>

                {/* Testimonial */}
                <div className={`neon-card neon-card-${study.color} p-6`}>
                  <div className="flex items-center gap-2 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className={`w-5 h-5 neon-text-${study.color} fill-current`} />
                    ))}
                  </div>
                  <blockquote className="text-lg text-gray-300 mb-6 italic">
                    "{study.testimonial.quote}"
                  </blockquote>
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-full neon-icon-bg-${study.color} flex items-center justify-center neon-text-${study.color} font-bold neon-glow-${study.color}`}>
                      {study.testimonial.author[0]}
                    </div>
                    <div>
                      <div className="font-semibold text-white neon-text-glow">{study.testimonial.author}</div>
                      <div className="text-sm text-gray-400">{study.testimonial.role}, {study.client}</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Background decoration */}
            <div className={`absolute top-0 right-0 w-32 h-32 neon-corner-glow-${study.color} opacity-20`}></div>
          </motion.div>
        ))}
      </div>

      {/* CTA Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center mt-16"
      >
        <div className="neon-card neon-card-cyan p-8">
          <h3 className="text-2xl md:text-3xl font-bold neon-text-gradient mb-4">
            Ready to Be Our Next Success Story?
          </h3>
          <p className="text-lg text-gray-300 mb-6">
            Join 150+ businesses that have transformed their growth with our proven strategies.
          </p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="neon-btn-primary"
          >
            <ArrowRight size={20} />
            Get Your Free Strategy Session
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
}