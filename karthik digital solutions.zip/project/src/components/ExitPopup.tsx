import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Download } from 'lucide-react';

export default function ExitPopup() {
  const [isVisible, setIsVisible] = useState(false);
  const [hasShown, setHasShown] = useState(false);

  useEffect(() => {
    const handleMouseLeave = (e: MouseEvent) => {
      if (e.clientY <= 0 && !hasShown) {
        setIsVisible(true);
        setHasShown(true);
      }
    };

    document.addEventListener('mouseleave', handleMouseLeave);
    return () => document.removeEventListener('mouseleave', handleMouseLeave);
  }, [hasShown]);

  const handleDownload = () => {
    window.location.href = `mailto:karthikeya.gsi@gmail.com?subject=Request: The Complete Guide to Green Marketing&body=I'd like to receive the free guide "The Complete Guide to Green Marketing That Actually Converts".`;
    setIsVisible(false);
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50"
            onClick={() => setIsVisible(false)}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-lg bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-8 border border-white/10 z-50"
          >
            <button
              onClick={() => setIsVisible(false)}
              className="absolute top-4 right-4 text-white/60 hover:text-white"
            >
              <X size={24} />
            </button>

            <h3 className="text-2xl font-bold text-white mb-4">
              Wait! Don't Miss Out on Sustainable Growth
            </h3>

            <p className="text-slate-300 mb-6">
              Get our complete guide to green marketing that actually converts. Learn how to increase your ROI while reducing environmental impact.
            </p>

            <div className="bg-white/5 rounded-xl p-4 mb-6">
              <ul className="space-y-3">
                <li className="flex items-center gap-2 text-slate-300">
                  <div className="w-2 h-2 rounded-full bg-emerald-400"></div>
                  Proven strategies from 50+ successful case studies
                </li>
                <li className="flex items-center gap-2 text-slate-300">
                  <div className="w-2 h-2 rounded-full bg-emerald-400"></div>
                  Step-by-step implementation guide
                </li>
                <li className="flex items-center gap-2 text-slate-300">
                  <div className="w-2 h-2 rounded-full bg-emerald-400"></div>
                  ROI calculation templates included
                </li>
              </ul>
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleDownload}
              className="w-full bg-gradient-to-r from-emerald-400 to-blue-500 text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2"
            >
              <Download size={20} />
              Download Free Guide
            </motion.button>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}