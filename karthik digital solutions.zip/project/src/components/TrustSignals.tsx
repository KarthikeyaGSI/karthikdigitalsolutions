import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Users, TrendingUp, DollarSign, Zap, Star, Award, CheckCircle, Globe } from 'lucide-react';

const stats = [
  {
    icon: <DollarSign className="w-6 h-6 neon-text-cyan" />,
    value: "$2.5M+",
    label: "Revenue Generated for Clients",
    color: "cyan"
  },
  {
    icon: <TrendingUp className="w-6 h-6 neon-text-pink" />,
    value: "150%",
    label: "Average ROI Increase",
    color: "pink"
  },
  {
    icon: <Users className="w-6 h-6 neon-text-purple" />,
    value: "150+",
    label: "Successful Projects Delivered",
    color: "purple"
  },
  {
    icon: <CheckCircle className="w-6 h-6 neon-text-green" />,
    value: "98%",
    label: "Client Satisfaction Rate",
    color: "green"
  },
];

const testimonials = [
  {
    quote: "Working with Karthik was a game-changer for our business. Our online sales increased by 180% in just 4 months, and the ROI continues to grow. Best investment we've made.",
    author: "Sarah Johnson",
    role: "CEO",
    company: "TechStart Solutions",
    rating: 5,
    color: "cyan",
    results: "+180% Sales Growth"
  },
  {
    quote: "The strategic approach helped us reduce customer acquisition costs by 60% while tripling our qualified leads. The results speak for themselves - exceptional work.",
    author: "Michael Rodriguez",
    role: "Marketing Director", 
    company: "Green Energy Corp",
    rating: 5,
    color: "pink",
    results: "+320% Lead Generation"
  },
  {
    quote: "From feast or famine to predictable monthly revenue. The lead nurturing system is incredible - 40% of our clients now come from referrals. Highly recommended.",
    author: "David Park",
    role: "Managing Partner",
    company: "Professional Services Firm",
    rating: 5,
    color: "purple",
    results: "+240% Conversion Rate"
  }
];

const clientLogos = [
  "TechStart Solutions",
  "Green Energy Corp", 
  "E-commerce Plus",
  "Professional Services",
  "Digital Innovations",
  "Growth Partners",
  "Market Leaders",
  "Success Stories",
  "Revenue Builders",
  "Scale Masters",
  "Profit Makers",
  "Growth Hackers"
];

const certifications = [
  {
    name: "Google Partner",
    description: "Certified Google Ads Expert",
    color: "cyan"
  },
  {
    name: "Meta Business Partner", 
    description: "Facebook & Instagram Ads Specialist",
    color: "pink"
  },
  {
    name: "HubSpot Certified",
    description: "Inbound Marketing Expert",
    color: "purple"
  },
  {
    name: "Analytics Expert",
    description: "Google Analytics 4 Certified",
    color: "green"
  }
];

export default function TrustSignals() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <div ref={ref} className="py-16 relative z-10">
      <div className="container mx-auto px-4">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          className="text-3xl md:text-4xl font-bold mb-4 text-center neon-text-gradient"
        >
          Trusted by <span className="neon-text-cyan">150+</span> Growing Businesses
        </motion.h2>
        <p className="text-base md:text-lg text-gray-300 text-center mb-12 max-w-2xl mx-auto">
          Join successful businesses that have transformed their growth with our proven strategies and measurable results.
        </p>

        {/* Key Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`neon-card neon-card-${stat.color} text-center transform hover:scale-105 transition-transform duration-300`}
            >
              <div className="flex justify-center mb-4">
                <div className={`w-12 h-12 neon-icon-bg-${stat.color} rounded-xl flex items-center justify-center neon-glow-${stat.color}`}>
                  {stat.icon}
                </div>
              </div>
              <div className="text-3xl md:text-4xl font-bold neon-text-gradient mb-2">
                {stat.value}
              </div>
              <div className="text-sm text-gray-400">{stat.label}</div>
            </motion.div>
          ))}
        </div>

        {/* Client Testimonials */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
              animate={inView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
              className={`neon-card neon-card-${testimonial.color} transform hover:scale-105 transition-transform duration-300`}
            >
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className={`w-5 h-5 neon-text-${testimonial.color} fill-current`} />
                  ))}
                </div>
                <div className={`inline-block px-3 py-1 rounded-full text-sm neon-text-${testimonial.color} border border-current mb-4`}>
                  {testimonial.results}
                </div>
              </div>
              <blockquote className="text-lg text-gray-300 mb-6">"{testimonial.quote}"</blockquote>
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-full neon-icon-bg-${testimonial.color} flex items-center justify-center neon-text-${testimonial.color} font-bold neon-glow-${testimonial.color}`}>
                  {testimonial.author[0]}
                </div>
                <div>
                  <div className="font-semibold text-white neon-text-glow">{testimonial.author}</div>
                  <div className="text-sm text-gray-400">{testimonial.role}</div>
                  <div className="text-sm text-gray-500">{testimonial.company}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Client Logos */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="mb-16"
        >
          <h3 className="text-xl font-semibold text-center text-gray-400 mb-8">
            Trusted by Industry Leaders
          </h3>
          <div className="grid grid-cols-3 md:grid-cols-6 gap-6">
            {clientLogos.map((logo, index) => (
              <div key={index} className="neon-card neon-card-cyan p-4 text-center">
                <div className="w-8 h-8 mx-auto mb-2 neon-icon-bg-cyan rounded-lg flex items-center justify-center">
                  <Globe className="w-4 h-4 neon-text-cyan" />
                </div>
                <div className="text-xs text-gray-400">{logo}</div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Certifications */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.8 }}
          className="text-center"
        >
          <h3 className="text-2xl font-bold neon-text-gradient mb-8 flex items-center justify-center gap-2">
            <Award className="w-6 h-6" />
            Certified Excellence & Expertise
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {certifications.map((cert, index) => (
              <div key={index} className={`neon-card neon-card-${cert.color} text-center`}>
                <div className={`w-12 h-12 mx-auto mb-4 neon-icon-bg-${cert.color} rounded-xl flex items-center justify-center neon-glow-${cert.color}`}>
                  <Award className={`w-6 h-6 neon-text-${cert.color}`} />
                </div>
                <h4 className={`font-semibold neon-text-${cert.color} mb-2`}>{cert.name}</h4>
                <p className="text-sm text-gray-400">{cert.description}</p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Social Proof CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 1.0 }}
          className="mt-16 text-center"
        >
          <div className="neon-card neon-card-cyan p-8">
            <h3 className="text-2xl font-bold neon-text-gradient mb-4">
              Join Our Success Stories
            </h3>
            <p className="text-lg text-gray-300 mb-6">
              Ready to see similar results for your business? Let's discuss your growth strategy.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="neon-btn-primary"
            >
              <Zap size={20} />
              Get Your Free Strategy Session
            </motion.button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}