import React from 'react';
import { motion } from 'framer-motion';
import { Download, FileText, TrendingUp, Leaf, Zap, Sparkles } from 'lucide-react';

const caseStudies = [
  {
    company: "EcoTech Solutions",
    results: {
      sales: 150,
      carbon: 30,
      timeline: "6 months"
    },
    quote: "GSI transformed our digital presence while maintaining our commitment to sustainability.",
    color: "cyan"
  },
  {
    company: "Green Energy Corp",
    results: {
      sales: 200,
      carbon: 25,
      timeline: "8 months"
    },
    quote: "Their sustainable marketing approach helped us reduce costs and increase engagement.",
    color: "pink"
  }
];

export default function LeadMagnets() {
  const handleDownload = () => {
    window.location.href = `mailto:karthikeya.gsi@gmail.com?subject=Request: The Complete Guide to Green Marketing&body=I'd like to receive the free guide "The Complete Guide to Green Marketing That Actually Converts".`;
  };

  return (
    <section className="py-24 relative z-10">
      <div className="container mx-auto px-4">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="text-3xl md:text-4xl font-bold mb-12 text-center neon-text-gradient"
        >
          <Sparkles className="inline w-8 h-8 mr-2" />
          Neon <span className="neon-text-cyan">Resources</span> & Success Stories
        </motion.h2>

        <div className="grid md:grid-cols-2 gap-12">
          {/* Lead Magnet */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="neon-card neon-card-cyan"
          >
            <div className="flex items-center gap-4 mb-6">
              <div className="w-12 h-12 neon-icon-bg-cyan rounded-xl flex items-center justify-center neon-glow-cyan">
                <FileText className="w-6 h-6 neon-text-cyan" />
              </div>
              <h3 className="text-xl font-semibold text-white neon-text-glow">Free Marketing Guide</h3>
            </div>
            
            <h4 className="text-2xl font-bold text-white mb-4 neon-text-glow">
              The Complete Guide to <span className="neon-text-cyan">Green Marketing</span> That Actually Converts
            </h4>
            
            <ul className="space-y-3 mb-6">
              <li className="flex items-center gap-2 text-gray-300">
                <div className="w-2 h-2 rounded-full bg-cyan-400 neon-dot-glow"></div>
                Learn the exact framework we use to increase ROI
              </li>
              <li className="flex items-center gap-2 text-gray-300">
                <div className="w-2 h-2 rounded-full bg-pink-400 neon-dot-glow"></div>
                Step-by-step sustainability marketing playbook
              </li>
              <li className="flex items-center gap-2 text-gray-300">
                <div className="w-2 h-2 rounded-full bg-purple-400 neon-dot-glow"></div>
                Real case studies with actionable insights
              </li>
            </ul>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleDownload}
              className="neon-btn-primary w-full"
            >
              <Download size={20} />
              Download Free Guide
            </motion.button>
          </motion.div>

          {/* Case Studies */}
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-white mb-8 neon-text-glow">
              <Zap className="inline w-6 h-6 mr-2 neon-text-yellow" />
              Success Stories
            </h3>
            
            {caseStudies.map((study, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                className={`neon-card neon-card-${study.color}`}
              >
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-lg font-semibold text-white neon-text-glow">{study.company}</h4>
                  <span className="text-sm text-gray-400">{study.results.timeline}</span>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="neon-card neon-card-green p-4">
                    <div className="flex items-center gap-2 neon-text-green mb-2">
                      <TrendingUp size={16} />
                      <span className="text-sm">Sales Increase</span>
                    </div>
                    <div className="text-2xl font-bold text-white neon-text-glow">
                      +{study.results.sales}%
                    </div>
                  </div>
                  
                  <div className="neon-card neon-card-purple p-4">
                    <div className="flex items-center gap-2 neon-text-purple mb-2">
                      <Leaf size={16} />
                      <span className="text-sm">Carbon Reduction</span>
                    </div>
                    <div className="text-2xl font-bold text-white neon-text-glow">
                      {study.results.carbon}%
                    </div>
                  </div>
                </div>
                
                <blockquote className="text-gray-300 italic">
                  "{study.quote}"
                </blockquote>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}