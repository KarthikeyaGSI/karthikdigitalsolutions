import React from 'react';
import { motion } from 'framer-motion';
import { 
  Globe, 
  TrendingUp, 
  BarChart3, 
  Users, 
  CheckCircle, 
  ArrowRight, 
  Zap,
  Target,
  DollarSign,
  Clock
} from 'lucide-react';

interface ServicePackagesProps {
  onServiceClick: (service: string) => void;
}

const services = [
  {
    icon: <Globe className="w-8 h-8" />,
    title: "Revenue-Focused Web Development",
    description: "Custom websites and e-commerce platforms designed to convert visitors into customers with optimized user experience and proven conversion strategies.",
    features: [
      "High-converting landing pages",
      "E-commerce optimization",
      "Mobile-first responsive design",
      "Advanced analytics integration",
      "A/B testing implementation"
    ],
    expectedResult: "40-60% increase in online conversions",
    timeline: "2-4 weeks",
    investment: "$3,500 - $8,000",
    color: "cyan",
    roi: "250% average ROI"
  },
  {
    icon: <TrendingUp className="w-8 h-8" />,
    title: "Growth-Driven Digital Marketing",
    description: "Comprehensive marketing campaigns across multiple channels designed to generate qualified leads and drive measurable business growth.",
    features: [
      "SEO strategies for qualified traffic",
      "Social media lead generation",
      "Email marketing automation",
      "Content marketing strategy",
      "Conversion optimization"
    ],
    expectedResult: "3x increase in qualified leads",
    timeline: "1-2 weeks setup",
    investment: "$2,500 - $6,000/month",
    color: "pink",
    roi: "300% average ROI"
  },
  {
    icon: <BarChart3 className="w-8 h-8" />,
    title: "Marketing Automation & Analytics",
    description: "Complete funnel optimization with advanced tracking, CRM integration, and automated nurturing systems to maximize customer lifetime value.",
    features: [
      "Complete funnel optimization",
      "Advanced tracking & reporting",
      "CRM integration & lead scoring",
      "Automated email sequences",
      "Performance dashboards"
    ],
    expectedResult: "50% reduction in customer acquisition cost",
    timeline: "2-3 weeks",
    investment: "$4,000 - $10,000",
    color: "purple",
    roi: "400% average ROI"
  },
  {
    icon: <Users className="w-8 h-8" />,
    title: "Business Growth Consulting",
    description: "Strategic consulting and planning to identify growth opportunities, optimize operations, and create a clear roadmap to scale your business.",
    features: [
      "Digital strategy development",
      "Market analysis & positioning",
      "Competitive advantage planning",
      "Growth roadmap creation",
      "Performance optimization"
    ],
    expectedResult: "Clear roadmap to 2x revenue",
    timeline: "1-2 weeks",
    investment: "$2,000 - $5,000",
    color: "green",
    roi: "500% average ROI"
  }
];

const packages = [
  {
    name: "Starter Growth Package",
    price: "$3,500 - $5,000",
    description: "Perfect for small businesses ready to establish their digital presence",
    features: [
      "Website optimization",
      "Basic marketing setup",
      "Analytics implementation",
      "3-month support",
      "Monthly performance reports"
    ],
    roi: "2x investment within 6 months",
    color: "cyan",
    popular: false
  },
  {
    name: "Business Accelerator",
    price: "$7,500 - $12,000",
    description: "Complete digital transformation for growing businesses",
    features: [
      "Complete website development",
      "Advanced marketing campaigns",
      "Marketing automation",
      "6-month ongoing optimization",
      "Dedicated account manager"
    ],
    roi: "3x investment within 9 months",
    color: "pink",
    popular: true
  },
  {
    name: "Enterprise Solution",
    price: "Custom Pricing",
    description: "Full-service partnership for established businesses",
    features: [
      "Custom development & strategy",
      "Multi-channel campaigns",
      "Advanced analytics & reporting",
      "Dedicated support team",
      "Quarterly strategy reviews"
    ],
    roi: "Custom ROI based on scale",
    color: "purple",
    popular: false
  }
];

export default function ServicePackages({ onServiceClick }: ServicePackagesProps) {
  return (
    <div className="space-y-16">
      {/* Individual Services */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {services.map((service, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            whileHover={{ y: -5 }}
            className={`neon-card neon-card-${service.color} group cursor-pointer`}
            onClick={() => onServiceClick(service.title)}
          >
            <div className={`w-16 h-16 neon-icon-bg-${service.color} rounded-2xl flex items-center justify-center neon-text-${service.color} mb-6 neon-glow-${service.color}`}>
              {service.icon}
            </div>
            
            <h3 className="text-2xl font-bold text-white mb-4 neon-text-glow">{service.title}</h3>
            <p className="text-gray-300 mb-6">{service.description}</p>
            
            <div className="space-y-3 mb-6">
              {service.features.map((feature, idx) => (
                <div key={idx} className="flex items-center gap-3">
                  <CheckCircle className={`w-5 h-5 neon-text-${service.color} flex-shrink-0`} />
                  <span className="text-gray-300">{feature}</span>
                </div>
              ))}
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className={`neon-card neon-card-${service.color} p-4`}>
                <Target className={`w-5 h-5 neon-text-${service.color} mb-2`} />
                <div className="text-sm text-gray-400">Expected Result</div>
                <div className="font-semibold text-white">{service.expectedResult}</div>
              </div>
              <div className={`neon-card neon-card-${service.color} p-4`}>
                <DollarSign className={`w-5 h-5 neon-text-${service.color} mb-2`} />
                <div className="text-sm text-gray-400">ROI</div>
                <div className="font-semibold text-white">{service.roi}</div>
              </div>
            </div>
            
            <div className="flex items-center justify-between pt-4 border-t border-gray-700">
              <div>
                <div className="text-sm text-gray-400">Investment</div>
                <div className={`font-bold neon-text-${service.color}`}>{service.investment}</div>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-gray-400" />
                <span className="text-sm text-gray-400">{service.timeline}</span>
              </div>
            </div>
            
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className={`w-full mt-6 neon-btn-secondary border-${service.color}-400 text-${service.color}-400 hover:bg-${service.color}-400 hover:text-black`}
            >
              Learn More
              <ArrowRight size={18} />
            </motion.button>
          </motion.div>
        ))}
      </div>

      {/* Package Pricing */}
      <div className="mt-16">
        <motion.h3 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="text-2xl md:text-3xl font-bold mb-4 text-center neon-text-gradient"
        >
          Investment <span className="neon-text-cyan">Packages</span>
        </motion.h3>
        <p className="text-base md:text-lg text-gray-300 text-center mb-12 max-w-2xl mx-auto">
          Choose the package that fits your business goals and budget. All packages include our ROI guarantee.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {packages.map((pkg, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`neon-card neon-card-${pkg.color} relative ${pkg.popular ? 'scale-105' : ''}`}
            >
              {pkg.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="neon-btn-primary px-4 py-2 text-sm">
                    <Zap size={16} />
                    Most Popular
                  </div>
                </div>
              )}
              
              <div className="text-center mb-6">
                <h4 className="text-2xl font-bold text-white mb-2 neon-text-glow">{pkg.name}</h4>
                <div className={`text-3xl font-bold neon-text-${pkg.color} mb-2`}>{pkg.price}</div>
                <p className="text-gray-400">{pkg.description}</p>
              </div>
              
              <div className="space-y-3 mb-6">
                {pkg.features.map((feature, idx) => (
                  <div key={idx} className="flex items-center gap-3">
                    <CheckCircle className={`w-5 h-5 neon-text-${pkg.color} flex-shrink-0`} />
                    <span className="text-gray-300">{feature}</span>
                  </div>
                ))}
              </div>
              
              <div className={`neon-card neon-card-${pkg.color} p-4 mb-6 text-center`}>
                <div className="text-sm text-gray-400 mb-1">ROI Promise</div>
                <div className={`font-bold neon-text-${pkg.color}`}>{pkg.roi}</div>
              </div>
              
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onServiceClick(pkg.name)}
                className={`w-full ${pkg.popular ? 'neon-btn-primary' : 'neon-btn-secondary'}`}
              >
                Get Started
                <ArrowRight size={18} />
              </motion.button>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Value Justification */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        className="neon-card neon-card-green p-8 text-center"
      >
        <h3 className="text-2xl font-bold neon-text-green mb-4">Why This Investment Makes Sense</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h4 className="text-xl font-semibold text-white mb-4">Cost of Inaction</h4>
            <ul className="space-y-2 text-gray-300">
              <li>• Businesses lose $10,000+ monthly from poor digital presence</li>
              <li>• Delayed implementation costs 6x more than proactive investment</li>
              <li>• Competitors gain market share while you wait</li>
            </ul>
          </div>
          <div>
            <h4 className="text-xl font-semibold text-white mb-4">ROI Demonstration</h4>
            <ul className="space-y-2 text-gray-300">
              <li>• Average client sees 150% ROI within 6 months</li>
              <li>• Investment typically pays for itself in 90 days</li>
              <li>• Ongoing benefits compound over time</li>
            </ul>
          </div>
        </div>
      </motion.div>
    </div>
  );
}